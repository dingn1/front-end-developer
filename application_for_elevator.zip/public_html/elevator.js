var j = 1;
var timer = 1;// elevator running or not
var Height = [0, 0, 0, 0];
var events = 0;// how many events are to be executed
var eventb = 1;
var l = 0;// the length of scroll movement done by the elevator
var Heights = 0;// the length to be moved by the elevator in order to finish one requirement
var k;
var type;
var time;
window.scrollTo(0, findPos(document.getElementById(1)));//set the level to 1
document.documentElement.style.overflow = 'hidden';//avoid unnecessary moves the move canonly be conrolled by the button
var floor=document.getElementsByClassName("floor-number")[0].innerHTML;
var elevator = document.getElementsByClassName("floor-select-button");
for (var i = 0; i < elevator.length; i++) {  //the Heights of elements
    Height[i] = document.getElementById(i + 1).scrollHeight;
}
for (var i = 0; i < elevator.length; i++) {      //the event listener
    elevator[i].addEventListener("click", control);
}
var s = 1;
var con = [];

//main control function for all the events.
function control(event) {
    var status = 0;
    if (timer === 0) {
        var add = 1; // if you would alw adding  to the event array
        for (var i = 0; i < con.length; i++) {
            if (con[i] != event.target.textContent)
            {
                add = 1;
            }
            else {
                add = 0;
                break;
            }
        }
        if (add == 1 && (type == "up" || type == "down" || event.target.textContent != floor)) {
            con[s] = event.target.textContent;
            document.getElementsByClassName("floor-select-button")[event.target.textContent - 1].style.backgroundColor = "red";


            if (con[s] < floor && type == "down" && con[s] > eventb) {

                con.sort(function (a, b) {
                    return b - a;
                });
                type = "";
                clearInterval(time);
                events++;
                // con.unshift(0);
                eventb = con[0];
                s++;
                Heights = 0;
                ele();
            }

            else if (con[s] > floor && type == "up" && con[s] < eventb) {
                con.sort(function (a, b) {
                    return a - b
                });
                type = "";
                clearInterval(time);
                events++;
                eventb = con[0];
                s++;
                Heights = 0;
                ele();
            }

            else if (floor == 3 && type == "up") {
                events++;
                s++;
            }

            else if (floor == 2 && type == "down") {
                events++;
                s++;
            }

            else if (type === "up" && Math.abs(con[s - 1] - eventb) <= Math.abs(con[s] - con[s - 2]) && (con[s - 1] < eventb || con[s] < eventb))
            {
                con.sort(function (a, b) {
                    return a - b
                });
                var min = con[0];
                for (var i = 0; i < con.length; i++)
                    con[i] = con[i + 1];
                con[s] = min;
                s++;
                events++;
            }

            else if (type === "down" && Math.abs(con[s - 1] - eventb) >= Math.abs(con[s] - con[s - 2]) && (con[s - 1] > eventb || con[s] > eventb)) {
                con.sort(function (a, b) {
                    return b - a
                });
                var max = con[0];
                for (var i = 0; i < con.length; i++)
                    con[i] = con[i + 1];
                con[s] = max;
                events++;
                s++;
            }

            else if (type == "up") {
                status = 0;
                for (var i = 0; i < con.length; i++) {
                    if (con[i] < eventb)
                        status = 1;
                }
                if (status == 0) {
                    con.sort(function (a, b) {
                        return a - b;
                    });
                }
                s++;
                events++;
            }

            else if (type == "down") {
                status = 0;
                for (var i = 0; i < con.length; i++) {
                    if (con[i] > eventb)
                        status = 1;
                }
                if (status == 0) {
                    con.sort(function (a, b) {
                        return b - a;
                    });
                    alert(con);
                }
                s++;
                events++;
            }

            else
            {
                status = 0;
                for (var i = 0; i < con.length; i++) {
                    if (con[i] > floor)
                        status = 1;
                }
                if (status == 0) {
                    con.sort(function (a, b) {
                        return b - a;
                    });
                }
                status = 0;
                for (var i = 0; i < con.length; i++) {
                    if (con[i] < floor)
                        status = 1;
                }
                if (status == 0) {
                    con.sort(function (a, b) {
                        return a - b;
                    });
                }
                s++;
                events++;

            }
        }
        else
        {

        }
    }
    if (timer === 1 && events === 0)
    {
        con[0] = event.target.textContent;
        if (eventb != con[0])
        {
            events++;
            eventb = con[0];
            ele();
        }

        else {
        }
    }
    if (timer === 1 && events !== 0) {
        con.shift();
        s--;
        if (con[0] !== 0) {
            eventb = con[0];
            ele();
        }
    }
}

//scroll up or scroll down chooser
function ele() {
    timer = 0;
    if (j > eventb)
    {
        for (k = j; k > eventb; k--) {
            Heights = Heights + Height[k - 1];
        }
        k = j;
        time = setInterval(scroll, 10);
    }

    else {
        for (k = j; k < eventb; k++) {
            Heights = Heights + Height[k - 1];
        }
        k = j;
        time = setInterval(scrolls, 10);
    }
}

function findPos(obj) {
    var curtop = 0;
    if (obj.offsetParent) {
        do {
            curtop += obj.offsetTop;
        } while (obj == obj.offsetParent);
        return [curtop];
    }
}

//scroll down function
function scroll() {
    type = "down";
    document.getElementById("down-indicator").style.opacity = 100;
    document.getElementsByClassName("floor-select-button")[eventb - 1].style.backgroundColor = "red";
    window.scrollBy(0, 1);
    l++;
    if (l % Height[0] === 0 && l !== Heights) {
        floor = parseInt(k) - 1;
        document.getElementsByClassName("floor-number")[0].innerHTML = parseInt(k) - 1;
        k--;
    }
    if (l === Heights) {
        document.getElementById("down-indicator").style.opacity = 0;
        floor = eventb;
        document.getElementsByClassName("floor-select-button")[eventb - 1].style.backgroundColor = "white";
        events--;
        Heights = 0;
        j = eventb;
        l = 0;
        type = "";
        document.getElementsByClassName("floor-number")[0].innerHTML = parseInt(k) - 1;
        clearInterval(time);
        if (floor == 1) {
            con.sort(function (a, b) {
                return a - b
            });
        }
        setTimeout(co, 5000);
    }
}

//scroll up function
function scrolls()
{
    type = "up";
    document.getElementById("up-indicator").style.opacity = 100;
    document.getElementsByClassName("floor-select-button")[eventb - 1].style.backgroundColor = "red";
    window.scrollBy(0, -1);
    l++;
    if (l === Heights)
    {
        document.getElementById("up-indicator").style.opacity = 0;
        floor = eventb;
        document.getElementsByClassName("floor-select-button")[eventb - 1].style.backgroundColor = "white";
        events--;
        Heights = 0;
        j = eventb;
        l = 0;
        type = "";
        document.getElementsByClassName("floor-number")[0].innerHTML = parseInt(k) + 1;
        clearInterval(time);
        if (floor == 4) {
            con.sort(function (a, b) {
                return b - a;
            });
        }
        setTimeout(co, 5000);
    }
    if (l % Height[0] === 0 && l !== Heights) {
        floor = parseInt(k) + 1;
        document.getElementsByClassName("floor-number")[0].innerHTML = parseInt(k) + 1;
        k++;
    }
}

//check if there is undone event
function co() {
    timer = 1;
    if (events !== 0) {
        control();
    }

    else {
        con = [];
    }
}
